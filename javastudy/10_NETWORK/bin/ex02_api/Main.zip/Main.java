package ex02_api;


import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        
    	
        try {
           
        	
        	
        	Scanner sc = new Scanner(System.in);
        	System.out.println("번역할 언어 선택");
        	System.out.println("1.한국어 2.영어");
        	System.out.print("선택 >>> ");
        	int No = sc.nextInt();
        	
        	
        
            String apiUrl = "https://openapi.naver.com/v1/papago/n2mt";
            URL url = new URL(apiUrl);
            HttpURLConnection con = (HttpURLConnection)url.openConnection();

        	
            if(No == 1) {
            
            System.out.println("번역할 텍스트를 입력하세요.");
            System.out.print("입력 >>> ");
            String text = sc.next();
            String encodedStr1 = URLEncoder.encode(text, "UTF-8");
            String postParams1 = "source=ko&target=en&text=" + encodedStr1; //원본언어: 한국어 (ko) -> 목적언어: 영어 (en)
            System.out.println("결과 >>> " + postParams1);
            
            } else {
            	 System.out.println("번역할 텍스트를 입력하세요.");
            	 System.out.print("입력 >>> ");
                 String text = sc.next();
                 String encodedStr2 = URLEncoder.encode(text, "UTF-8");
                 String postParams2 = "source=en&target=ko&text=" + encodedStr2; //원본언어: 영어 (en) -> 목적언어: 한국어 (ko)
                 System.out.println("결과 >>> " + postParams2);
            }
			con.disconnect();
            	            
            
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
			System.out.println("API 주소 오류");
		} catch (IOException e) {
			System.out.println("API 접속 오류");
		}

       }

}