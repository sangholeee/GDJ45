package ex02_loop;

public class Quiz01 {

	public static void main(String[] args) {

		// 평점에 따른 별(★) 출력하기
		
	
		int star = 4;
		String res = "";                   // 빈 문자열    int z 처럼 한 번 정의해주는 것.
		
		for(int n = 1; n <= star; n++)     
			res += "★";                    
		
		System.out.println(res);
		
		
		
		
		
		
		
	}

}
