package ex02_date_time;

import java.util.Date;

public class Ex03_java_util_Date {

	public static void main(String[] args) {

		// java.util 패키지에 저장된 Date 클래스
		// Oracle Database에 저장 X
		
		Date now = new Date();
		
		System.out.println(now);
				
	}

}
