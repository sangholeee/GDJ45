package com.goodee.test0622.service;

import com.goodee.test0622.domain.SearchVO;

public interface ProductService {

	public String productSearch(SearchVO search);
	
}
