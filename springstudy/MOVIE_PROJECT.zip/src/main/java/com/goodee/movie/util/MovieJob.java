package com.goodee.movie.util;

import org.springframework.stereotype.Component;

// Scheduler! 
@Component  // 안녕. 난 bean이야.
public class MovieJob {
/*
	@Autowired
	private BoardMapper boardMapper;
	
	
	@Scheduled(cron = "0/10 * * * * ?")  // 크론식 -> 10초마다 동작 (JSP 07_BATCH / StudentLitsenr) 
	public void execute() {
		System.out.println("---쿼츠 동작 중---");
		System.out.println(boardMapper.selectBoardCount());
	}
	
	*/
}
